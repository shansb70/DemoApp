﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DemoApplication.Models
{
    public class EmployeeModel
    {

        public string EmpFirstName { get; set; }

        public string EmpLastName { get; set; }

        public string EmpDepartment { get; set; }

    }
}
