﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Employee.Data.Models
{
    public class EmployeeData
    {
        public string EmpFirstName { get; set; }

        public string EmpLastName { get; set; }

        public string EmpDepartment { get; set; }

    }
}
