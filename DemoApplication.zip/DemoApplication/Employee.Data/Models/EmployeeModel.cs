﻿using Employee.Data.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;
using System.IO;

namespace Employee.Data.Models
{
    public class EmployeeModel : IEmployeeRepository
    {
     
        public string CreateEmployeeDetails(EmployeeData employeeData)
        {
            EmployeeData empdata = new EmployeeData()
            {
                EmpFirstName = employeeData.EmpFirstName,
                EmpLastName = employeeData.EmpLastName,
                EmpDepartment = employeeData.EmpDepartment
            };

 
            List<EmployeeData> fdata = new List<EmployeeData>();
            fdata.Add(empdata);
            String json = JsonConvert.SerializeObject(fdata.ToArray());
        
            File.WriteAllText(AppDomain.CurrentDomain.BaseDirectory + @"\TEST2.TXT", json);
            return "File Saved in " + AppDomain.CurrentDomain.BaseDirectory + @"TEST2.TXT";



        }
    }
}
